public class City {
    String name;
    String airway;
    String highway;
    String railway;
}
