public class Countries {
    float population;
    float areatotal;
    float arealand;
    float areawater;
    float agemale;
    float agefemale;
    float brate;
    float drate;
    float litfemale;
    float airports;
    String name;


    /* This is my countries file which creates objects that holds values of that country.Purpose of this is
    to find the name of that value and also to find that country correspond to that value.*/
}
